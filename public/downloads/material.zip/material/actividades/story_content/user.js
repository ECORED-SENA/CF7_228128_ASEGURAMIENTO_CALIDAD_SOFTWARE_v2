function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6CB7UTUMd4x":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

